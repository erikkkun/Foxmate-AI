import json
import numpy as np
import random
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import joblib
from datetime import datetime


class FocusClassifier:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.tag_encoder = LabelEncoder()
        self.app_encoder = LabelEncoder()

    def load_data(self, focused_file, unfocused_file):
        "加载训练数据"
        focused_data = []
        unfocused_data = []

        # 读取专注数据
        with open(focused_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if line:  # 跳过空行
                    try:
                        focused_data.append(json.loads(line))
                    except json.JSONDecodeError as e:
                        print(f"警告: 专注数据第{line_num}行格式错误，已跳过")

        # 读取分心数据
        with open(unfocused_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if line:  # 跳过空行
                    try:
                        unfocused_data.append(json.loads(line))  # ✅ 这里要用 unfocused_data
                    except json.JSONDecodeError as e:
                        print(f"警告: 分心数据第{line_num}行格式错误，已跳过")

        return focused_data, unfocused_data

    def extract_features(self, data_point):
        "提取特征"
        features = {
            'keystrokes_per_min': data_point['keystrokes_per_min'],
            'mouse_px_per_min': data_point['mouse_px_per_min'],
            'pred_focus': data_point['pred_focus'],
            'app': data_point['app'],
            'tags': data_point['tags']
        }
        return features

    def prepare_training_data(self, focused_data, unfocused_data):
        "准备训练数据"
        X = []
        y = []

        all_apps = []
        all_tags = []

        # 收集所有应用和标签
        for data in focused_data + unfocused_data:
            all_apps.append(data['app'])
            all_tags.append(data['tags'])

        # 训练编码器
        self.app_encoder.fit(all_apps)
        self.tag_encoder.fit(all_tags)

        # 处理专注数据 (标签=1)
        for data in focused_data:
            features = [
                data['keystrokes_per_min'],
                data['mouse_px_per_min'],
                data['pred_focus'],
                self.app_encoder.transform([data['app']])[0],
                self.tag_encoder.transform([data['tags']])[0]
            ]
            X.append(features)
            y.append(1)  # 专注

        # 处理分心数据 (标签=0)
        for data in unfocused_data:
            features = [
                data['keystrokes_per_min'],
                data['mouse_px_per_min'],
                data['pred_focus'],
                self.app_encoder.transform([data['app']])[0],
                self.tag_encoder.transform([data['tags']])[0]
            ]
            X.append(features)
            y.append(0)  # 分心

        return np.array(X), np.array(y)

    def train(self, focused_file, unfocused_file):
        "训练模型"
        print("加载数据...")
        focused_data, unfocused_data = self.load_data(focused_file, unfocused_file)

        print(f"专注数据: {len(focused_data)} 条")
        print(f"分心数据: {len(unfocused_data)} 条")

        print("\n准备训练数据...")
        X, y = self.prepare_training_data(focused_data, unfocused_data)

        # 分割训练集和测试集
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        print("\n训练模型...")
        self.model.fit(X_train, y_train)

        # 评估模型
        train_score = self.model.score(X_train, y_train)
        test_score = self.model.score(X_test, y_test)

        print(f"\n训练准确率: {train_score:.2%}")
        print(f"测试准确率: {test_score:.2%}")

        return train_score, test_score

    def predict(self, data_point):
        "预测单个数据点"
        features = [
            data_point['keystrokes_per_min'],
            data_point['mouse_px_per_min'],
            data_point['pred_focus'],
            self.app_encoder.transform([data_point['app']])[0],
            self.tag_encoder.transform([data_point['tags']])[0]
        ]

        prediction = self.model.predict([features])[0]
        probability = self.model.predict_proba([features])[0]

        return prediction, probability

    def get_reminder(self, data_point, prediction, probability):
        "根据预测结果生成提醒"
        is_focused = prediction == 1
        confidence = probability[prediction] * 100

        if is_focused:
            return {
                'status': '专注',
                'confidence': confidence,
                'message': f'✅ 很好！你正在专注于 {data_point["title"]}，继续保持！'
            }
        else:
            # 分析分心原因
            app = data_point['app']
            title = data_point['title']
            tags = data_point['tags']

            if 'entertainment' in tags:
                reason = '你似乎在看娱乐内容'
            elif 'gaming' in tags:
                reason = '你似乎在玩游戏'
            elif 'social' in tags:
                reason = '你似乎在社交媒体上'
            elif 'browsing' in tags:
                reason = '你似乎在随意浏览'
            elif 'shopping' in tags:
                reason = '你似乎在购物'
            else:
                reason = '你似乎分心了'

            return {
                'status': '分心',
                'confidence': confidence,
                'message': f'⚠️ {reason}（{title}）\n💡 建议：关闭干扰源，回到你的重要任务上！',
                'suggestion': self.get_focus_suggestion(data_point)
            }

    def get_focus_suggestion(self, data_point):
        "提供专注建议"
        # 从数据中提取时间，而不是用当前时间
        try:
            from datetime import datetime
            ts = datetime.fromisoformat(data_point['ts'].replace('Z', '+00:00'))
            hour = ts.hour
        except:
            # 如果解析失败，使用当前时间
            hour = datetime.now().hour

        morning_tips = [
            '☀️ 早上的阳光正好，大脑也最清醒～这是专注的黄金时刻！',
            '🌅 清晨是一天中最有活力的时候，好好利用这段时光吧！',
            '🌤️ 早晨的你精力充沛，现在专注起来效率会特别高哦！',
            '🌻 新的一天开始啦，让我们用最好的状态迎接挑战吧！'
        ]

        afternoon_tips = [
            '🍵 下午容易疲劳呢，要不起来走走、喝口水？休息5分钟再继续～',
            '☕ 午后时光，大脑可能有点累了，深呼吸放松一下再出发！',
            '🌤️ 下午了，感觉累的话就站起来伸伸懒腰，活动一下更好哦～',
            '💆 下午时段注意力容易分散，不如稍作休息再重新投入？'
        ]

        evening_tips = [
            '🌙 晚上了，如果感觉疲惫，明天再处理也完全可以的～别太勉强自己！',
            '✨ 夜深了，今天辛苦了！如果实在累了，不如明天精神好再继续？',
            '🌃 晚上大脑需要休息啦，要不今天就到这里，明天继续加油？',
            '💫 夜晚时分，注意保重身体哦～休息好了才能更好地工作！'
        ]

        general_tips = [
            '💡 试试把手机放远一点，让诱惑离你远一些～',
            '🎯 用番茄工作法怎么样？专注25分钟，然后休息5分钟！',
            '📝 要不列个小清单？看着完成的事情一项项划掉会很有成就感哦！',
            '🎧 播放一些轻柔的背景音乐，也许能帮你进入专注状态～',
            '🧘 深呼吸3次，让心情平静下来，然后重新开始吧！',
            '🎨 把当前不需要的标签页都关掉，给自己一个清爽的工作环境！',
            '⏰ 设个小目标，比如专注完成这件事再去放松，会更有动力！',
            '🌟 回想一下今天想要完成什么，然后一步步来，不着急～',
            '💪 你已经做得很好了！再坚持一下，完成后好好奖励自己！',
            '🎁 完成这个任务后，给自己安排一个小奖励怎么样？'
        ]

        # 根据时间段选择建议
        if hour < 12:
            time_tips = morning_tips
        elif hour < 18:
            time_tips = afternoon_tips
        else:
            time_tips = evening_tips

        # 随机返回一个时间建议或通用建议
        if random.random() < 0.6:  # 60%概率返回时间相关建议
            return random.choice(time_tips)
        else:  # 40%概率返回通用建议
            return random.choice(general_tips)

    def save_model(self, filename='focus_model.pkl'):
        "保存模型"
        model_data = {
            'model': self.model,
            'app_encoder': self.app_encoder,
            'tag_encoder': self.tag_encoder
        }
        joblib.dump(model_data, filename)
        print(f"\n模型已保存到 {filename}")

    def load_model(self, filename='focus_model.pkl'):
        "加载模型"
        model_data = joblib.load(filename)
        self.model = model_data['model']
        self.app_encoder = model_data['app_encoder']
        self.tag_encoder = model_data['tag_encoder']
        print(f"模型已从 {filename} 加载")


# 使用示例
if __name__ == "__main__":
    # 创建分类器
    classifier = FocusClassifier()

    # 训练模型（注意文件名有空格）
    classifier.train('focused_data.txt', 'not_focused_data.txt')

    # 保存模型
    classifier.save_model()

    # 测试预测
    test_data = {
        "ts": "2025-10-05T14:00:00.000000",
        "app": "chrome.exe",
        "title": "YouTube - Funny Videos",
        "keystrokes_per_min": 0,
        "mouse_px_per_min": 12000.0,
        "tags": "behavior, entertainment",
        "pred_focus": 35.5
    }

    prediction, probability = classifier.predict(test_data)
    reminder = classifier.get_reminder(test_data, prediction, probability)

    print("\n" + "=" * 50)
    print("预测结果:")
    print(f"状态: {reminder['status']}")
    print(f"置信度: {reminder['confidence']:.1f}%")
    print(f"提醒: {reminder['message']}")
    if 'suggestion' in reminder:

        print(f"建议: {reminder['suggestion']}")
