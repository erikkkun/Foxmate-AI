import json
from AI import FocusClassifier


def process_data(input_file, output_file):
    """
    读取数据文件，用AI分析，只输出提示和建议

    参数:
        input_file: 输入文件路径（每行一条JSON数据）
        output_file: 输出文件路径
    """
    print("🤖 加载AI模型...")
    classifier = FocusClassifier()
    classifier.load_model('focus_model.pkl')
    print("✅ 开始处理...\n")

    with open(input_file, 'r', encoding='utf-8') as input_f:
        with open(output_file, 'w', encoding='utf-8') as output_f:
            count = 0

            for line in input_f:
                line = line.strip()
                if not line:
                    continue

                try:
                    # 解析数据
                    data = json.loads(line)

                    # AI分析
                    prediction, probability = classifier.predict(data)
                    reminder = classifier.get_reminder(data, prediction, probability)

                    # 只写入提示和建议
                    output_f.write(f"{reminder['message']}\n")

                    if 'suggestion' in reminder and reminder['suggestion']:
                        output_f.write(f"{reminder['suggestion']}\n")

                    output_f.write("\n")  # 空行分隔

                    count += 1
                    if count % 10 == 0:
                        print(f"   已处理: {count} 条")

                except Exception as e:
                    continue  # 跳过错误数据

    print(f"\n✅ 完成！共处理 {count} 条数据")
    print(f"📄 结果已保存到: {output_file}")


if __name__ == "__main__":
    # 在这里设置你的文件路径
    INPUT_FILE = 'input_data.txt'  # 输入文件
    OUTPUT_FILE = 'result.txt'  # 输出文件


    process_data(INPUT_FILE, OUTPUT_FILE)
